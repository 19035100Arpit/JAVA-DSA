# CodingNinjas_Java_DSA_Premium_Solution
Course Taken on Date - 16-March-2022
1. I will be updating this repository as I progess with the course.
2. The codes only contain the solutions to the problems. This means no main methods, no data structure initializations etc.
3. The codes will NOT run by simply copy and pasting. You will need to write the main method and other excess code if you are running them somewhere other than coding ninjas.
![LOGO-05](https://user-images.githubusercontent.com/68940229/187216740-97b52d77-9801-431c-abce-2b9edcd5b599.png)
# Appendix
Please star the github section and purchase the React Course from the link provided on the right. You will get a 10-20% discount using my link provided to you on the right. Enjoy..........
# Disclaimer
Before jumping onto the solution, try for yourself! 
Happy Coding be a Ninja Coder.
